"""TechCareer Salary Predictor - interactive dashboard.

Files needed beside this app.py:
    techcareer_salary_model.pkl   (required)  trained RandomForestRegressor
    techcareer_features.pkl       (required)  the 50 column names the model expects
    techcareer_scaler.pkl         (optional)  StandardScaler used in training -> exact experience/rating
    india_job_market_2024_2026.csv (optional) training data -> real-data charts + calibration

Run:  streamlit run app.py
"""
import inspect
import re
import warnings
from pathlib import Path
from typing import NamedTuple

import joblib
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import sklearn
import streamlit as st

# ------------------------------------------------------------------ settings
BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "techcareer_salary_model.pkl"
FEATURE_PATH = BASE_DIR / "techcareer_features.pkl"
SCALER_PATH = BASE_DIR / "techcareer_scaler.pkl"
DATA_PATH = BASE_DIR / "india_job_market_2024_2026.csv"

LAKH = 100_000                 # 1 LPA = Rs 1,00,000 per year
UNIT = "LPA"                   # the model's predictions (about 18-75) look like lakhs per annum
NUM_EXP, NUM_RAT = "Experience_Years", "Company_Rating"
RATING_FALLBACK = (3.698, 0.425)   # (mean, std) recovered from the model's split points; see About tab

# (field name, label shown to the user, one-hot column prefix)
CATS = [
    ("title", "Job title", "Job_Title_"),
    ("company", "Company type", "Company_Type_"),
    ("location", "Location tier", "Location_Tier_"),
    ("mode", "Work mode", "Work_Mode_"),
    ("education", "Education required", "Education_Required_"),
]
HIGHLIGHT, MUTED, ACCENT = "#E4572E", "#B4BEDC", "#3A2E8F"

st.set_page_config(page_title="TechCareer Salary Predictor", page_icon="💼", layout="wide", initial_sidebar_state="collapsed")
st.markdown(
    """
    <style>
    .block-container{padding-top:1.4rem;max-width:1250px;}
    #MainMenu, footer{visibility:hidden;}
    /* hero banner */
    .hero{background:linear-gradient(120deg,#1B2A49 0%,#3A2E8F 55%,#E4572E 130%);border-radius:20px;
        padding:26px 32px;color:#fff;margin-bottom:18px;box-shadow:0 8px 24px rgba(40,30,110,.25);}
    .hero h1{margin:0;font-size:1.9rem;color:#fff;} .hero p{margin:4px 0 0;opacity:.85;font-size:.95rem;}
    /* big prediction card */
    .pred{background:linear-gradient(135deg,#E4572E,#F29E4C);border-radius:20px;padding:26px 30px;color:#fff;
        box-shadow:0 8px 22px rgba(228,87,46,.30);height:100%;}
    .pred .lbl{font-size:.85rem;text-transform:uppercase;letter-spacing:.08em;opacity:.9;}
    .pred .big{font-size:3.2rem;font-weight:800;line-height:1.1;margin:6px 0;}
    .pred .sub{font-size:1rem;opacity:.95;}
    .chip{display:inline-block;background:rgba(255,255,255,.22);border-radius:999px;padding:4px 12px;
        font-size:.85rem;margin:10px 6px 0 0;}
    /* small stat cards */
    .stat{background:rgba(128,128,128,.08);border:1px solid rgba(128,128,128,.22);border-left:5px solid #3A2E8F;
        border-radius:14px;padding:14px 18px;margin-bottom:12px;}
    .stat .k{font-size:.78rem;text-transform:uppercase;letter-spacing:.06em;opacity:.7;}
    .stat .v{font-size:1.5rem;font-weight:700;margin-top:2px;}
    /* tips */
    .tip{background:rgba(58,46,143,.10);border-radius:12px;padding:10px 14px;margin-bottom:8px;}
    .tip b{color:#E4572E;}
    div[data-testid="stMetric"]{background:rgba(128,128,128,.08);border:1px solid rgba(128,128,128,.22);
        border-radius:14px;padding:12px 16px;}
    button[data-baseweb="tab"]{font-size:1.05rem;font-weight:600;}
    </style>
    """,
    unsafe_allow_html=True,
)


def stretch(func):
    """Full-width keyword that works on old and new Streamlit versions."""
    params = inspect.signature(func).parameters
    if "width" in params:
        return {"width": "stretch"}
    if "use_container_width" in params:
        return {"use_container_width": True}
    return {}


PLOT = stretch(st.plotly_chart)
TABLE = stretch(st.dataframe)


# ------------------------------------------------------------------ loading
@st.cache_resource(show_spinner="Loading model...")
def load_artifacts():
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        model = joblib.load(MODEL_PATH)
        features = list(joblib.load(FEATURE_PATH))
    version_warning = any("version" in str(w.message).lower() for w in caught)
    model.n_jobs = 1                      # small batches: threads would only add overhead

    # split points the forest uses on the experience column (tells us its distinct levels)
    idx = features.index(NUM_EXP)
    values = set()
    for est in model.estimators_:
        tree = est.tree_
        values.update(np.round(tree.threshold[tree.feature == idx], 5).tolist())
    merged = []
    for v in sorted(values):
        if not merged or v - merged[-1] > 1e-3:
            merged.append(v)

    scaler = joblib.load(SCALER_PATH) if SCALER_PATH.exists() else None
    return model, features, version_warning, merged, scaler


@st.cache_data(show_spinner=False)
def read_csv(path):
    return pd.read_csv(path)


try:
    MODEL, FEATURES, VERSION_WARNING, EXP_SPLITS, SCALER = load_artifacts()
except FileNotFoundError as error:
    st.error(f"Missing file: {error.filename}. Keep the .pkl files in the same folder as app.py.")
    st.stop()
except Exception as error:
    st.error(f"Could not load the model: {error}")
    st.stop()

PREFIXES = [p for _, _, p in CATS]
IDX = {f: i for i, f in enumerate(FEATURES)}
OPTIONS = {k: [f[len(p):] for f in FEATURES if f.startswith(p)] for k, _, p in CATS}

problems = [lab for k, lab, _ in CATS if not OPTIONS[k]]
if NUM_EXP not in IDX or NUM_RAT not in IDX or problems or len(FEATURES) != MODEL.n_features_in_:
    st.error("The feature list does not match this app (expected Experience_Years, Company_Rating and "
             "one-hot columns Job_Title_*, Company_Type_*, Location_Tier_*, Work_Mode_*, Education_Required_*).")
    st.stop()

DATA = read_csv(str(DATA_PATH)) if DATA_PATH.exists() else None


# ------------------------------------------------------------------ calibration of the 2 scaled columns
def column_stats(col):
    """(mean, std, source) for a numeric column, using scaler file > CSV > None."""
    if SCALER is not None:
        names = list(getattr(SCALER, "feature_names_in_", [NUM_EXP, NUM_RAT]))
        if col in names:
            i = names.index(col)
            return float(SCALER.mean_[i]), float(SCALER.scale_[i]), "techcareer_scaler.pkl (exact)"
    if DATA is not None and col in DATA.columns and pd.api.types.is_numeric_dtype(DATA[col]):
        s = DATA[col].dropna()
        return float(s.mean()), float(s.std(ddof=0)), "training CSV (close approximation)"
    return None


rat_stats = column_stats(NUM_RAT)
RAT_MEAN, RAT_STD, RAT_SOURCE = rat_stats if rat_stats else (*RATING_FALLBACK, "inferred from the model (approximate)")

# Experience: the training data holds 5 experience levels. The model's split points match these
# representative years exactly (Fresher 0.5, Junior 2, Mid 4.5, Senior 8, Lead 10), so users just enter years.
EXP_LEVELS = [("Fresher", "0-1 yr", 1, 0.5), ("Junior", "1-3 yrs", 3, 2.0), ("Mid-level", "3-6 yrs", 6, 4.5),
              ("Senior", "6-10 yrs", 10, 8.0), ("Lead", "10+ yrs", None, 10.0)]
E_MEAN, E_STD = 4.2004, 3.14487517        # mean / std of the 5 levels over the 5,000 training rows
EXP_SOURCE = "years entered by the user, grouped into the 5 levels the model was trained on"
EXP_YEARS = list(range(0, 16))


def exp_level(years):
    for i, (_, _, upper, _) in enumerate(EXP_LEVELS):
        if upper is None or years < upper:
            return i


def exp_name(years):
    name, rng, _, _ = EXP_LEVELS[exp_level(years)]
    return f"{name} ({rng})"


def exp_z(years):
    return (EXP_LEVELS[exp_level(years)][3] - E_MEAN) / E_STD

if DATA is not None and NUM_RAT in DATA.columns and pd.api.types.is_numeric_dtype(DATA[NUM_RAT]):
    r_lo, r_hi = float(DATA[NUM_RAT].min()), float(DATA[NUM_RAT].max())
else:
    r_lo, r_hi = 1.5, 5.0
RATINGS = [round(v, 1) for v in np.arange(round(r_lo, 1), r_hi + 0.01, 0.1)]


# ------------------------------------------------------------------ profile -> model input
class Profile(NamedTuple):
    title: str
    company: str
    location: str
    mode: str
    education: str
    exp: int
    rating: float


def encode(profiles):
    X = np.zeros((len(profiles), len(FEATURES)))
    for r, p in enumerate(profiles):
        X[r, IDX[NUM_EXP]] = exp_z(p.exp)
        X[r, IDX[NUM_RAT]] = (p.rating - RAT_MEAN) / RAT_STD
        for (field, _, prefix) in CATS:
            X[r, IDX[prefix + getattr(p, field)]] = 1.0
    return pd.DataFrame(X, columns=FEATURES)


@st.cache_data(show_spinner=False, max_entries=512)
def predict(profiles):
    return MODEL.predict(encode(profiles))


@st.cache_data(show_spinner=False, max_entries=256)
def tree_predictions(profile):
    X = encode([profile]).to_numpy(dtype=np.float32)
    return np.array([est.predict(X)[0] for est in MODEL.estimators_])


def sweep(profile, field, values):
    return predict(tuple(profile._replace(**{field: v}) for v in values))


def lpa(x):
    return f"₹{x:,.1f} {UNIT}"


def per_year(x):
    return f"₹{x * LAKH:,.0f} per year"


def profile_inputs(key, containers, defaults=None):
    """Draw the 7 dropdowns and return a Profile."""
    defaults = defaults or {}
    box = lambda i: containers[i % len(containers)]
    vals = {}
    for i, (field, label, _) in enumerate(CATS):
        opts = OPTIONS[field]
        start = opts.index(defaults[field]) if defaults.get(field) in opts else 0
        vals[field] = box(i).selectbox(label, opts, index=start, key=f"{key}_{field}")
    vals["exp"] = box(5).slider("Years of experience", 0, 15, defaults.get("exp", 3), key=f"{key}_exp",
                                help="The model groups experience into 5 levels: 0-1, 1-3, 3-6, 6-10 and 10+ years.")
    box(5).caption(f"Counts as: **{exp_name(vals['exp'])}**")
    r_default = RATINGS.index(4.0) if 4.0 in RATINGS else len(RATINGS) // 2
    vals["rating"] = box(6).selectbox("Company rating", RATINGS, index=r_default, key=f"{key}_rating",
                                      format_func=lambda v: f"{v:.1f} ★")
    return Profile(**vals)


# ------------------------------------------------------------------ shared data (CSV beside app.py, or uploaded)
DF = DATA if DATA is not None else st.session_state.get("uploaded_df")


def salary_column(df):
    numeric = [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
    like = [c for c in numeric if any(w in c.lower() for w in ("salary", "ctc", "lpa", "compensation", "pay"))]
    return (like or numeric or [None])[0]


def split_skills(value):
    if pd.isna(value):
        return []
    text = str(value).strip().strip("[]")
    return [s.strip(" '\"") for s in re.split(r"[,;|]", text) if s.strip(" '\"")]


def skills_long(df, sal):
    """One row per (posting, skill). Handles a text column of skills or one-hot Skill_* columns."""
    numeric = [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
    text_cols = [c for c in df.columns if "skill" in c.lower() and c not in numeric]
    onehot = [c for c in numeric if c.lower().startswith("skill") and set(df[c].dropna().unique()) <= {0, 1}]
    keep = [c for c in (sal, "Job_Title") if c and c in df.columns]
    if text_cols:
        col = text_cols[0] if len(text_cols) == 1 else st.selectbox("Skills column", text_cols)
        tmp = df[keep].copy()
        tmp["skill"] = df[col].map(split_skills)
        return tmp.explode("skill").dropna(subset=["skill"])
    if onehot:
        parts = []
        for c in onehot:
            part = df.loc[df[c] == 1, keep].copy()
            part["skill"] = re.sub(r"^skills?[_ ]", "", c, flags=re.I).replace("_", " ")
            parts.append(part)
        return pd.concat(parts, ignore_index=True)
    return None


def clean(fig, height=360, **kw):
    fig.update_layout(height=height, margin=dict(l=10, r=30, t=50, b=10), plot_bgcolor="rgba(0,0,0,0)",
                      paper_bgcolor="rgba(0,0,0,0)", title_font_size=16, **kw)
    return fig


def bar_chart(values, labels, current, title, height=380):
    order = np.argsort(values)
    v = np.array(values)[order]
    l = np.array(labels, dtype=object)[order]
    colors = [HIGHLIGHT if x == current else MUTED for x in l]
    fig = go.Figure(go.Bar(x=v, y=l, orientation="h", marker_color=colors,
                           text=[f"{x:,.1f}" for x in v], textposition="outside", cliponaxis=False))
    fig.update_layout(xaxis_title=f"Estimated salary ({UNIT})", yaxis_title=None)
    fig.update_xaxes(range=[0, float(v.max()) * 1.18])
    return clean(fig, height, title=title)


# ------------------------------------------------------------------ header
st.markdown(
    f"""<div class="hero"><h1>💼 TechCareer Salary Predictor</h1>
    <p>Predict a tech job's salary and see what drives it · salaries in lakhs per annum ({UNIT}), 1 {UNIT} = ₹1,00,000 / year</p></div>""",
    unsafe_allow_html=True,
)

tab_pred, tab_ana, tab_skill, tab_data = st.tabs(["🎯 Prediction", "📊 Analysis", "🛠️ Skills", "🗂️ Dataset"])

# ------------------------------------------------------------------ TAB 1: prediction
with tab_pred:
    PREFERRED = {"title": "Data Scientist", "company": "MNC", "location": "Tier 1", "mode": "Hybrid", "education": "B.Tech/B.E."}
    A_DEFAULTS = {k: v for k, v in PREFERRED.items() if v in OPTIONS[k]}
    with st.container(border=True):
        row1, row2 = st.columns(4), st.columns(3)
        A = profile_inputs("a", list(row1) + list(row2), A_DEFAULTS)

    pred = float(predict((A,))[0])
    trees = tree_predictions(A)
    p10, p90 = np.percentile(trees, [10, 90])
    titles_pred = sweep(A, "title", OPTIONS["title"])
    rank = int((titles_pred > pred + 1e-9).sum()) + 1

    left, right = st.columns([1.15, 1])
    with left:
        st.markdown(
            f"""<div class="pred"><div class="lbl">Estimated salary</div>
            <div class="big">₹{pred:,.1f} {UNIT}</div>
            <div class="sub">{per_year(pred)}</div>
            <span class="chip">Likely range: {p10:,.1f} – {p90:,.1f} {UNIT}</span>
            <span class="chip">Rank #{rank} of {len(OPTIONS['title'])} job titles</span></div>""",
            unsafe_allow_html=True)
    with right:
        gains = []
        for field, label, _ in CATS:
            opts = OPTIONS[field]
            vals = sweep(A, field, opts)
            j = int(np.argmax(vals))
            if opts[j] != getattr(A, field) and vals[j] - pred > 0.05:
                gains.append((vals[j] - pred, label, opts[j]))
        ys = sweep(A, "exp", EXP_YEARS)
        best_years = EXP_YEARS[int(np.argmax(ys))]
        if exp_level(best_years) != exp_level(A.exp) and ys.max() - pred > 0.05:
            gains.append((ys.max() - pred, "Experience", f"{EXP_LEVELS[exp_level(best_years)][1]}"))
        gains.sort(reverse=True)
        st.markdown("**🚀 Top ways to earn more** (change one thing)")
        if gains:
            for g, label, opt in gains[:3]:
                st.markdown(f'<div class="tip">{label} → <b>{opt}</b> &nbsp; +{g:,.1f} {UNIT}</div>', unsafe_allow_html=True)
        else:
            st.success("You already have the best option for every factor.")

    c1, c2 = st.columns(2)
    with c1, st.container(border=True):
        st.plotly_chart(bar_chart(titles_pred, OPTIONS["title"], A.title, "Salary by job title",
                                  height=max(380, 24 * len(OPTIONS["title"]) + 80)), **PLOT)
    with c2, st.container(border=True):
        fig = go.Figure(go.Scatter(x=EXP_YEARS, y=ys, mode="lines", line=dict(color=ACCENT, width=3, shape="hv"),
                                   fill="tozeroy", fillcolor="rgba(58,46,143,0.10)"))
        fig.add_trace(go.Scatter(x=[A.exp], y=[pred], mode="markers", marker=dict(size=16, color=HIGHLIGHT)))
        fig.update_layout(showlegend=False, xaxis_title="Years of experience", yaxis_title=f"Estimated salary ({UNIT})")
        st.plotly_chart(clean(fig, 380, title="Salary growth with experience"), **PLOT)
    st.caption("Orange = your choice. Values are model estimates, not guaranteed offers. "
               "Likely range = spread of the model's 100 trees.")

# ------------------------------------------------------------------ TAB 2: analysis
with tab_ana:
    imp = pd.Series(MODEL.feature_importances_, index=FEATURES)
    groups = {"Experience": imp[NUM_EXP], "Company rating": imp[NUM_RAT]}
    for field, label, prefix in CATS:
        groups[label] = imp[[f for f in FEATURES if f.startswith(prefix)]].sum()
    g = pd.Series(groups).sort_values()
    c1, c2 = st.columns(2)
    with c1, st.container(border=True):
        colors = [HIGHLIGHT if i == len(g) - 1 else MUTED for i in range(len(g))]
        fig = go.Figure(go.Bar(x=g.values * 100, y=g.index, orientation="h", marker_color=colors,
                               text=[f"{v * 100:.0f}%" for v in g.values], textposition="outside", cliponaxis=False))
        fig.update_xaxes(range=[0, g.max() * 118])
        fig.update_layout(xaxis_title="Share of importance (%)")
        st.plotly_chart(clean(fig, 360, title="What matters most for salary"), **PLOT)
    with c2:
        if DF is None or salary_column(DF) is None:
            st.info("Add `india_job_market_2024_2026.csv` beside `app.py` to see market charts.")
        else:
            sal = salary_column(DF)
            with st.container(border=True):
                if "Experience_Level" in DF.columns:
                    order = [f"{n} ({r})" for n, r, _, _ in EXP_LEVELS]
                    lv = {lab: f"{n} ({r})" for lab, (n, r) in zip(
                        ["Fresher (0-1 yr)", "Junior (1-3 yrs)", "Mid (3-6 yrs)", "Senior (6-10 yrs)", "Lead (10+ yrs)"],
                        [(n, r) for n, r, _, _ in EXP_LEVELS])}
                    t = DF.assign(Level=DF["Experience_Level"].map(lv)).groupby("Level")[sal].mean().reindex(order)
                    fig = go.Figure(go.Bar(x=t.index, y=t.values, marker_color=HIGHLIGHT,
                                           text=[f"{v:,.1f}" for v in t.values], textposition="outside", cliponaxis=False))
                    fig.update_layout(yaxis_title=f"Average salary ({UNIT})")
                    st.plotly_chart(clean(fig, 360, title="Average salary by experience"), **PLOT)

    if DF is not None and salary_column(DF) is not None:
        sal = salary_column(DF)
        cat_cols = [c for c in ("Job_Title", "Company_Type", "Industry", "City", "Education_Required", "Work_Mode", "Job_Type")
                    if c in DF.columns]
        k1, k2, k3 = st.columns(3)
        k1.metric("Job postings analysed", f"{len(DF):,}")
        k2.metric("Median salary", f"{DF[sal].median():,.1f} {UNIT}")
        k3.metric("Average salary", f"{DF[sal].mean():,.1f} {UNIT}")
        with st.container(border=True):
            cat = st.selectbox("Compare average salary by", cat_cols) if cat_cols else None
            if cat:
                mean = DF.groupby(cat)[sal].mean().sort_values()
                fig = go.Figure(go.Bar(x=mean.values, y=mean.index, orientation="h", marker_color=ACCENT,
                                       text=[f"{v:,.1f}" for v in mean.values], textposition="outside", cliponaxis=False))
                fig.update_xaxes(range=[0, float(mean.max()) * 1.15])
                fig.update_layout(xaxis_title=f"Average salary ({UNIT})")
                st.plotly_chart(clean(fig, max(320, 26 * len(mean) + 80)), **PLOT)

# ------------------------------------------------------------------ TAB 3: skills
with tab_skill:
    if DF is None:
        st.info("Skill analysis needs the dataset. Add the CSV beside `app.py` or upload it in the **Dataset** tab.")
    else:
        sal = salary_column(DF)
        long = skills_long(DF, sal)
        if long is None or long.empty:
            st.warning("No skills column found in the CSV.")
        else:
            stats = long.groupby("skill").agg(Postings=("skill", "size"))
            if sal:
                stats["Avg salary"] = long.groupby("skill")[sal].mean()
            n = st.slider("Skills to show", 5, 25, 12)
            a, b = st.columns(2)
            with a, st.container(border=True):
                t = stats["Postings"].nlargest(n).sort_values()
                fig = go.Figure(go.Bar(x=t.values, y=t.index, orientation="h", marker_color=ACCENT))
                fig.update_layout(xaxis_title="Job postings")
                st.plotly_chart(clean(fig, max(340, 26 * n + 80), title="Most in-demand skills"), **PLOT)
            if sal:
                with b, st.container(border=True):
                    t = stats[stats["Postings"] >= 20]["Avg salary"].nlargest(n).sort_values()
                    fig = go.Figure(go.Bar(x=t.values, y=t.index, orientation="h", marker_color=HIGHLIGHT,
                                           text=[f"{v:,.1f}" for v in t.values], textposition="outside", cliponaxis=False))
                    fig.update_xaxes(range=[0, float(t.max()) * 1.15])
                    fig.update_layout(xaxis_title=f"Average salary ({UNIT})")
                    st.plotly_chart(clean(fig, max(340, 26 * n + 80), title="Highest-paying skills (20+ postings)"), **PLOT)
            if "Job_Title" in long.columns:
                titles = sorted(long["Job_Title"].dropna().unique())
                with st.container(border=True):
                    title = st.selectbox("Top skills for a job title", titles,
                                         index=titles.index(A.title) if A.title in titles else 0)
                    t = long[long["Job_Title"] == title]["skill"].value_counts().head(n).sort_values()
                    fig = go.Figure(go.Bar(x=t.values, y=t.index, orientation="h", marker_color=ACCENT))
                    fig.update_layout(xaxis_title="Job postings")
                    st.plotly_chart(clean(fig, max(320, 26 * len(t) + 80)), **PLOT)

# ------------------------------------------------------------------ TAB 4: dataset
with tab_data:
    if DF is None:
        st.info("No dataset found. Put `india_job_market_2024_2026.csv` beside `app.py`, or upload it below.")
        up = st.file_uploader("Upload the job-market CSV", type="csv")
        if up is not None:
            st.session_state["uploaded_df"] = pd.read_csv(up)
            st.rerun()
    else:
        k1, k2, k3, k4 = st.columns(4)
        k1.metric("Rows", f"{len(DF):,}")
        k2.metric("Columns", f"{DF.shape[1]}")
        k3.metric("Missing cells", f"{int(DF.isna().sum().sum()):,}")
        k4.metric("Duplicate rows", f"{int(DF.duplicated().sum()):,}")
        info = pd.DataFrame({"Column": DF.columns, "Type": [str(t) for t in DF.dtypes],
                             "Unique values": DF.nunique().values,
                             "Example": [str(DF[c].dropna().iloc[0]) if DF[c].notna().any() else "" for c in DF.columns]})
        with st.container(border=True):
            st.dataframe(info, hide_index=True, **TABLE)
        with st.expander("Preview first 100 rows"):
            st.dataframe(DF.head(100), **TABLE)
    st.caption(f"Model: {type(MODEL).__name__}, {getattr(MODEL, 'n_estimators', '?')} trees · "
               f"Experience: {EXP_SOURCE} · Company rating scale: {RAT_SOURCE}")
    if VERSION_WARNING:
        st.warning(f"Model was saved with another scikit-learn version (running {sklearn.__version__}). Use scikit-learn==1.6.1.")

st.caption("TechCareer Salary Predictor · Machine Learning Project")
