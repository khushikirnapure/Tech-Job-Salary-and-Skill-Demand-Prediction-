# TechCareer Salary Predictor

Run:
    py -3.12 -m pip install -r requirements.txt
    py -3.12 -m streamlit run app.py

Tabs: Prediction (enter job details + years of experience), Analysis, Skills, Dataset.
Keep the two .pkl files and india_job_market_2024_2026.csv in the same folder as app.py.
